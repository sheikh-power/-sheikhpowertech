import React from 'react';

export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to Sheikh Power Tech</h1>
      <p>Products: PVC Pipe, GI Fan Box, GI Circular, GI Modular Box</p>
      <p>Location: Jagatballavpur, Kolkata</p>
      <a href='https://wa.me/91629084176' target='_blank' rel='noopener noreferrer'>Order via WhatsApp</a>
    </div>
  );
}